<div class="footer-bottom-area">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="copyright pull-left">
                    <p>Copyright <a target="_blank" href="http://devitems.com/contact-us/">DevItems</a> All rights reserved.</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="paypal-img pull-right">
                    <img src="{{asset('img/paypal.png')}}" alt="">
                </div>
            </div>
        </div>
    </div>
</div>