
<div class="brand-area section-padding">
    <div class="container">
        <div class="row">
            <div class="section-title">
                <h2>OUR BRANDS</h2>
            </div>  
            <div class="brand-list indicator-style2">
                <div class="col-md-12">
                    <div class="single-brand">
                        <a href="#">
                            <img src="img/brand/1.jpg" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="single-brand">
                        <a href="#">
                            <img src="img/brand/2.jpg" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="single-brand">
                        <a href="#">
                            <img src="img/brand/3.jpg" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="single-brand">
                        <a href="#">
                            <img src="img/brand/4.jpg" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="single-brand">
                        <a href="#">
                            <img src="img/brand/5.jpg" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="single-brand">
                        <a href="#">
                            <img src="img/brand/1.jpg" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="single-brand">
                        <a href="#">
                            <img src="img/brand/2.jpg" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="single-brand">
                        <a href="#">
                            <img src="img/brand/3.jpg" alt="">
                        </a>
                    </div>
                </div>
            </div>                  
        </div>
    </div>
</div>        
        