<!doctype html>
<html class="no-js" lang="<?php echo e(app()->getLocale()); ?>">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <title><?php echo e(config('app.name', 'BrilliantEarth')); ?></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('img/favicon.ico')); ?>">
        <!-- Place favicon.ico in the root directory -->
        <!-- Google Fonts -->
		<link href='https://fonts.googleapis.com/css?family=Lato:400,300,300italic,400italic,700' rel='stylesheet' type='text/css'>

		<!-- all css here -->
		<!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
		<!-- animate css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.min.css')); ?>">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/meanmenu.min.css')); ?>">
		<!-- Font-Awesome css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
		<!-- Flaticon css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/flaticon.css')); ?>">
		<!-- venobox css -->
        <link rel="stylesheet" href="<?php echo e(asset('venobox/venobox.css')); ?>" type="text/css" media="screen" />
		<!-- nivo slider css -->
		<link rel="stylesheet" href="<?php echo e(asset('lib/css/nivo-slider.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(asset('lib/css/preview.css')); ?>" type="text/css" media="screen" />
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>">
		<!-- style css -->
		<link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
		<!-- responsive css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">
		<!-- modernizr css -->
        <script src="<?php echo e(asset('js/vendor/modernizr-2.8.3.min.js')); ?>"></script>

        <?php echo $__env->yieldContent('extra-script'); ?>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- Add your site or application content here -->
        <!--Header Area Start-->
        <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--Header Area End-->

        <?php echo $__env->yieldContent('content'); ?>

        <!-- Footer Area Start -->
        <?php echo $__env->make('inc.footerarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Footer Area End -->

        <!-- Footer Bottom Area -->
        <?php echo $__env->make('inc.footerbtm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Footer Bottom End -->

		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="<?php echo e(asset('js/vendor/jquery-1.12.0.min.js')); ?>"></script>
		<!-- bootstrap js -->
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
		<!-- owl.carousel js -->
        <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
		<!-- jquery-ui js -->
        <script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
		<!-- jquery countdown js -->
        <script src="<?php echo e(asset('js/jquery.countdown.min.js')); ?>"></script>
		<!-- jquery countdown js -->
        <script type="text/javascript" src="<?php echo e(asset('venobox/venobox.min.js')); ?>"></script>
		<!-- jquery Meanmenu js -->
        <script src="<?php echo e(asset('js/jquery.meanmenu.js')); ?>"></script>
		<!-- wow js -->
        <script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
		<!-- scrollUp JS -->
        <script src="<?php echo e(asset('js/jquery.scrollUp.min.js')); ?>"></script>
		<!-- plugins js -->
        <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
		<!-- Nivo slider js -->
		<script src="<?php echo e(asset('lib/js/jquery.nivo.slider.js')); ?>" type="text/javascript"></script>
		<script src="<?php echo e(asset('lib/home.js')); ?>" type="text/javascript"></script>
		<!-- main js -->
        <script src="<?php echo e(asset('js/main.js')); ?>"></script>

        <?php echo $__env->yieldContent('extra-js'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\BrilliantEarth\resources\views/layouts/app.blade.php ENDPATH**/ ?>