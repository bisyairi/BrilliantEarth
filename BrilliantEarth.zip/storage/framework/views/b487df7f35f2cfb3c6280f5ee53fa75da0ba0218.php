<?php $__env->startSection('content'); ?>
    <!-- Breadcrumbs Area Start -->
    <div class="breadcrumbs-area2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>SHOP LEFT SIDEBAR</h2>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumbs Area End -->
    <!-- Shop Page Area Start -->
    <div class="shop-page-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                    <div class="shop-widget">
                        <aside class="widget widget-categories">
                            <h2 class="sidebar-title">CATEGORY</h2>
                            <ul class="sidebar-menu">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e(setActiveCategory($category->slug)); ?>">
                                    <a href="<?php echo e(route('shop.index', ['category' => $category->slug])); ?>">
                                        <span class="widget-hover"><?php echo e($category->name); ?></span>
                                        <span>(<?php echo e($category->products_count); ?>)</span>
                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </aside>
                        <aside class="widget widget-shop-by">
                            <h3 class="sidebar-sub-title">Price</h3>
                            <div class="info-widget">
                                <div class="price_filter">
                                    <div id="slider-range"></div>
                                    <div class="price_slider_amount">
                                        <form action="<?php echo e(route('shop.index')); ?>" method="GET">
                                        <input style="width:75px" type="text" name="min_price" id="min_price" value="<?php echo e('RM'.number_format($minprice / 100, 2)); ?>"/>    -
                                        <input style="width:75px"type="text" name="max_price" id="max_price" value="<?php echo e('RM'.number_format($maxprice / 100, 2)); ?>"/> -
                                            <input type="submit" value="SEARCH" />
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </aside>
                        <aside class="widget widget-image">
                           <a href="#">
                               <img src="img/shop/side-bar.jpg" alt="">
                           </a>
                            <div class="widget-content">
                                <h2>Friday Sale <br>Extra <br>30% Off</h2>
                                <a href="#">Shop Now <i class="fa fa-angle-right"></i> </a>
                            </div>
                        </aside>
                    </div>
                </div>
                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                    <div class="shop-right-area">
                        <div class="shop-tab-list">
                            <div class="shop-left-tab">
                                <div class="shop-tab-pill pull-left">
                                    <ul>
                                        <li class="active" id="left"><a data-toggle="pill" href="#home"><i class="fa fa-th"></i><span></span></a></li>
                                        <li><a data-toggle="pill" href="#menu1"><i class="fa fa-th-list"></i><span></span></a></li>
                                    </ul>
                                </div>
                                <div class="shop-tab-pill pull-right">
                                    <ul>
                                        <li class="product-size-deatils">
                                            <div class="show-label">
                                                <label>Sort by : </label>
                                                <select onchange="location = this.value;">
                                                    <option value="position" selected="selected">Position</option>
                                                    <option value="<?php echo e(route('shop.index', ['category'=> request()->category, 'sort' => 'name'])); ?>">Name</option>
                                                    <option value="<?php echo e(route('shop.index', ['category'=> request()->category, 'sort' => 'price'])); ?>">Price</option>
                                                </select>
                                            </div>
                                        </li>
                                        <li class="product-size-deatils">
                                            <div class="show-label">
                                                <label>Show : </label>
                                                <select>
                                                    <option value="10" selected="selected">10</option>
                                                    <option value="09">09</option>
                                                    <option value="08">08</option>
                                                    <option value="07">07</option>
                                                    <option value="06">06</option>
                                                </select>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="shop-tab-pill pull-right">
                                    <div class="shop-pagination">
                                            <?php echo e($products->appends(request()->input())->render("pagination::bootstrap-4")); ?>

                                    </div>
                            </div>
                        </div>
                        <div class="tab-content">
                            <div class="row tab-pane fade in active" id="home">
                               <div class="shop-single-product-area">
                                   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <div class="col-md-4 col-sm-6">
                                       <div class="single-product">
                                           <a href="<?php echo e(route('shop.show', $product->slug)); ?>">
                                               <img src="<?php echo e(asset('img/'.$product->image)); ?>" alt="">
                                           </a>
                                           <div class="single-product-overlay <?php echo e($product->status); ?>">
                                               <h3><?php echo e($product->status_desc); ?></h3>
                                           </div>
                                           <div class="single-product-content">
                                              <div class="left-content pull-left">
                                                  <a href="<?php echo e(route('shop.show', $product->slug)); ?>"><h2><?php echo e($product->name); ?></h2></a>
                                                   <span class="new-price"><?php echo e($product->presentPrice()); ?></span>
                                              </div>
                                              <div class="right-content pull-right">
                                                  <a href="<?php echo e(route('shop.show', $product->slug)); ?>"><i class="flaticon-bag"></i></a>
                                              </div>
                                           </div>
                                       </div>
                                   </div>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </div>
                            </div>
                            <div id="menu1" class="tab-pane fade">
                                <div class="row">
                                    <div class="col-md-12">
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="shop-list-single">
                                            <div class="shop-list-left">
                                                <a href="#"><img style="width:270px; height:345px" src="<?php echo e(asset('img/product/'.$product->image)); ?>" alt="" /></a>
                                            </div>
                                            <div class="shop-list-right">
                                                <div class="left-content">
                                                    <a href="#"><h2><?php echo e($product->name); ?></h2></a>
                                                    <span class="new-price"><?php echo e($product->presentPrice()); ?></span>
                                                </div>
                                                <div class="list-pro-rating">
                                                    <i class="fa fa-star icolor"></i>
                                                    <i class="fa fa-star icolor"></i>
                                                    <i class="fa fa-star icolor"></i>
                                                    <i class="fa fa-star icolor"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <div class="product-desc">
                                                <?php echo $product->description; ?>

                                                </div>
                                                <a class="btn-default" href="#">SHOP NOW</a>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="shop-tab-list no-margin">
                            <div class="shop-left-tab">
                                <div class="shop-tab-pill pull-left">
                                    <ul>
                                        <li class="active first-margin"><a data-toggle="pill" href="#home"><i class="fa fa-th"></i><span></span></a></li>
                                        <li><a data-toggle="pill" href="#menu1"><i class="fa fa-th-list"></i><span></span></a></li>
                                    </ul>
                                </div>
                                <div class="shop-tab-pill pull-right">
                                    <ul>
                                        <li class="product-size-deatils">
                                            <div class="show-label">
                                                <label>Sort by : </label>
                                                <select onchange="location = this.value;">
                                                    <option value="position" selected="selected">Position</option>
                                                    <option value="<?php echo e(route('shop.index', ['category'=> request()->category, 'sort' => 'name'])); ?>">Name</option>
                                                    <option value="<?php echo e(route('shop.index', ['category'=> request()->category, 'sort' => 'price'])); ?>">Price</option>
                                                </select>
                                            </div>
                                        </li>
                                        <li class="product-size-deatils">
                                            <div class="show-label">
                                                <label>Show : </label>
                                                <select>
                                                    <option value="10" selected="selected">10</option>
                                                    <option value="09">09</option>
                                                    <option value="08">08</option>
                                                    <option value="07">07</option>
                                                    <option value="06">06</option>
                                                </select>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="shop-tab-pill pull-right">
                                <div class="shop-pagination">
                                    <?php echo e($products->appends(request()->input())->render("pagination::bootstrap-4")); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Shop Page Area End -->
    <br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <!-- Javascript -->
    <script>
        $(function() {


            $( "#slider-range" ).slider({
                range : true,
                min   : <?php echo $minprice; ?>,
                max   : <?php echo $maxprice; ?>,
                values: [ <?php echo $minprice; ?>, <?php echo $maxprice; ?> ],
                slide : function( event, ui ) {

                    var minprice = ui.values[ 0 ];
                    var maxprice = ui.values[ 1 ];

                    var a = minprice/100;
                    var b = maxprice/100;

                    $( "#min_price" ).val( "RM" + a.toFixed(2));
                    $( "#max_price" ).val( "RM" + b.toFixed(2));
                    }
            });
            // $( "#min_price" ).val( "RM" + $( "#slider-range" ).slider( "values", 0 )/100);
            // $( "#max_price" ).val( "RM" + $( "#slider-range" ).slider( "values", 1 )/100);
        });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BrilliantEarth\resources\views/pages/shop.blade.php ENDPATH**/ ?>