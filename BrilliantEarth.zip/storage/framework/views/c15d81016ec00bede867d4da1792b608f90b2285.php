<?php $__env->startSection('content'); ?>
    <!-- Breadcrumbs Area Start -->
    <div class="breadcrumbs-area2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Cart List</h2>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumbs Area End -->
    <!--Cart Page Area Start-->
    <div class="shopping-cart-area section-padding">
        <div class="container">

            <div class="row">
                <div class="col-md-12">

                    <?php if(session()->has('success_message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('success_message')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                     
                    <?php if(Cart::count() >0): ?>

                    <h2><?php echo e(Cart::count()); ?> item(s) in Shopping Cart</h2>

                    <div class="wishlist-table-area table-responsive">

                        <table>
                            <thead>
                                <tr>
                                    <th class="product-remove">Remove</th>
                                    <th class="product-image">Image</th>
                                    <th class="t-product-name">Product Name</th>
                                    
                                    <th class="product-unit-price">Unit Price</th>
                                    <th class="product-quantity">Quantity</th>
                                    <th class="product-subtotal">Subtotal</th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                                <tr>
                                    <td class="product-remove">
                                        <form id="remove" action="<?php echo e(route('cart.remove', $item->rowId)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" class="btn"><i class="fa fa-trash-o fa-2x"></i></button>
                                        </form>
                                    </td>
                                    <td class="product-image">
                                    <a href="<?php echo e(route('shop.show', $item->options->slug)); ?>">
                                            <img style="width:255px; height:280px" src="<?php echo e(asset('img/'.$item->options->image)); ?>" alt="">
                                        </a>
                                    </td>
                                    <td class="t-product-name">
                                        <h3>
                                            <a href="<?php echo e(route('shop.show', $item->options->slug)); ?>"><?php echo e($item->name); ?></a>
                                        </h3>
                                    <p><?php echo e($item->options->size); ?></p>
                                    <p><?php echo e($item->options->gemstone); ?></p>
                                    </td>
                                    <td class="product-unit-price">
                                        <p><?php echo e(presentPrice($item->price)); ?></p>
                                    </td>
                                    <td class="product-quantity product-cart-details">
                                        <select class="quantity" data-id="<?php echo e($item->rowId); ?>">
                                            <?php for($i = 1; $i < 6; $i++): ?>
                                                <option <?php echo e($item->qty == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </td>
                                    <td class="product-quantity">
                                        <p><?php echo e(presentPrice($item->subtotal)); ?></p>
                                    </td>
                                </tr>
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    <div class="shopingcart-bottom-area">
                        <a class="left-shoping-cart" role="button" href="<?php echo e(route('shop.index')); ?>">CONTINUE SHOPPING</a>
                        <div class="shopingcart-bottom-area pull-right">
                            <form id="removeall" action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <a id="clearall" class="right-shoping-cart" role="button">CLEAR SHOPPING CART</a>
                            </form>
                        </div>

                    </div>

                    <?php else: ?>
                        <h3>No items in Cart!</h3>
                        <br>
                        <div class="shopingcart-bottom-area">
                            <a class="left-shoping-cart" href="/shop">CONTINUE SHOPPING</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!--Cart Page Area End-->
    <!-- Discount Area Start -->
    <?php if(Cart::count() >0): ?>
    <div class="discount-area">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <div class="discount-main-area">
                        <div class="discount-top">
                            <h3>DISCOUNT CODE</h3>
                            <p>Enter your coupon code if have one</p>
                        </div>
                        <form id="couponform" action="<?php echo e(route('coupon.store')); ?>" method="POST">
                            <div class="discount-middle">
                                <?php echo csrf_field(); ?>
                                <input type="text" id="coupon_code" name="coupon_code" placeholder="ABC123">
                                <a role="button" id="applycoupon">APPLY COUPON</a>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="subtotal-main-area">
                        <div class="subtotal-area">
                            <h2>SUBTOTAL<span><?php echo e(presentPrice(Cart::subtotal())); ?></span></h2>
                        </div>
                        <?php if(session()->has('coupon')): ?>
                        <div class="subtotal-area">
                            <h2>DISCOUNT (<?php echo e(session()->get('coupon')['name']); ?>)
                                <form id="removeform" action="<?php echo e(route('coupon.destroy')); ?>" method="POST" style="display:inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a id="removecoupon">Remove</a>
                                </form>
                                <span>-<?php echo e(presentPrice($discount)); ?></span>
                            </h2>
                        </div>

                        <div class="subtotal-area">
                            <h2>NEW SUBTOTAL<span><?php echo e(presentPrice($newSubtotal)); ?></span></h2>
                        </div>
                        <?php endif; ?>

                        <div class="subtotal-area">
                            <h2>TAX (<?php echo e(config('cart.tax')); ?>%)<span><?php echo e(presentPrice($newTax)); ?></span></h2>
                        </div>
                        <div class="subtotal-area">
                            <h2>GRAND TOTAL<span><?php echo e(presentPrice($newTotal)); ?></span></h2>
                        </div>
                        <a href="<?php echo e(route('checkout.index')); ?>">CHECKOUT</a>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <br>
    <br>
    <br>
    <!-- Discount Area End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script type="text/javascript">

    (function(){
        const classname = document.querySelectorAll('.quantity')

        Array.from(classname).forEach(function(element){
            element.addEventListener('change', function(){
                // alert('Changed');

                const id = element.getAttribute('data-id')

                axios.patch(`cart/${id}`, {
                    quantity: this.value
                })

                .then(function (response) {
                    console.log(response);
                    window.location.href = '<?php echo e(route('cart.index')); ?>'
                    // console.log('lol');
                })
                .catch(function (error) {
                    console.log(error);
                    window.location.href = '<?php echo e(route('cart.index')); ?>'
                });
            })
        })
    })();

    document.getElementById("clearall").onclick = function() {
        document.getElementById("removeall").submit();
    }

    document.getElementById("applycoupon").onclick = function() {
        document.getElementById("couponform").submit();
    }

    document.getElementById("removecoupon").onclick = function() {
        document.getElementById("removeform").submit();
    }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BrilliantEarth\resources\views/pages/cart.blade.php ENDPATH**/ ?>