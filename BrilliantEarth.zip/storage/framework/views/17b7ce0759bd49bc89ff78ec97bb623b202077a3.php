<div class="header-cart pull-right">
    <ul>
        <li>
            <a class="header-cart-link" href="<?php echo e(route('cart.index')); ?>">
                <i class="flaticon-bag"></i>
                <?php if(Cart::instance('default')->count() > 0): ?>
                <span><?php echo e(Cart::instance('default')->count()); ?></span>
                <?php endif; ?>
            </a>
               <div class="cart_down_area">
                   <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="cart_single">
                       <a href="<?php echo e(route('shop.show', $item->options->slug)); ?>">
                           <img style="width:50px; height:70px" src="<?php echo e(asset('img/product/'.$item->options->image)); ?>" alt="">
                       </a>
                       <h2>
                           <a href="<?php echo e(route('shop.show', $item->options->slug)); ?>"><?php echo e($item->name); ?></a>
                           <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                           <button type="submit" class="btn btn-xs">
                               <span><i class="fa fa-trash"></i></span>
                           </button>
                        </form>
                       </h2>
                       <p><?php echo e($item->qty); ?> x <?php echo e(presentPrice($item->price)); ?></p>
                   </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <div class="cart_shoptings">
                       <a href="/checkout">Checkout</a>
                   </div>
               </div>
            </li>
        </ul>
    </div>
<?php /**PATH C:\xampp\htdocs\BrilliantEarth\resources\views/partials/header-cart.blade.php ENDPATH**/ ?>