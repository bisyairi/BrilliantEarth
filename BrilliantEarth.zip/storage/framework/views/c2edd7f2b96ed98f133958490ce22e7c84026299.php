<?php $__env->startSection('content'); ?>
    <!-- Breadcrumbs Area Start -->
    <div class="breadcrumbs-area2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>SHOP LEFT SIDEBAR</h2>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumbs Area End -->
    <!-- Shop Page Area Start -->
    <div class="shop-page-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">

                    <?php echo $__env->yieldContent('shop-widget'); ?>

                </div>
                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                    <div class="shop-right-area">

                        <?php echo $__env->yieldContent('shop-tab-list1'); ?>

                        <div class="tab-content">
                            <div class="row tab-pane fade in active" id="home">
                               <div class="shop-single-product-area">
                                   
                                   <p>lolllll</p>
                               </div>
                            </div>
                            <div id="menu1" class="tab-pane fade">
                                <div class="row">
                                    <div class="col-md-12">
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="shop-list-single">
                                            <div class="shop-list-left">
                                                <a href="#"><img style="width:270px; height:345px" src="<?php echo e(asset('img/product/'.$product->image)); ?>" alt="" /></a>                                          
                                            </div>  
                                            <div class="shop-list-right">
                                                <div class="left-content">
                                                    <a href="#"><h2><?php echo e($product->name); ?></h2></a>
                                                    <span class="new-price">RM <?php echo e($product->price); ?></span>
                                                </div>
                                                <div class="list-pro-rating">
                                                    <i class="fa fa-star icolor"></i>
                                                    <i class="fa fa-star icolor"></i>
                                                    <i class="fa fa-star icolor"></i>
                                                    <i class="fa fa-star icolor"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <div class="product-desc">
                                                <?php echo $product->description; ?>

                                                </div>
                                                <a class="btn-default" href="#">SHOP NOW</a>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php echo $__env->yieldContent('shop-tab-list2'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Shop Page Area End -->
    <br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <!-- Javascript -->
    <script>
        $(function() {
            $( "#slider-range" ).slider({
                range:true,
                min: <?php echo $minprice; ?>,
                max: <?php echo $maxprice; ?>,
                values: [ <?php echo $minprice; ?>, <?php echo $maxprice; ?> ],
                slide: function( event, ui ) {
                    $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
                    }
            });
            $( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) + " - $" + $( "#slider-range" ).slider( "values", 1 ) );
        });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BrilliantEarth\resources\views/pages/search-results.blade.php ENDPATH**/ ?>